using System;
using System.Drawing;

namespace GameTools 
{
	/// <summary>
	/// Summary description for PowerUp.
	/// </summary>
	public class PowerUp : GameObject
	{
		protected int type;
		protected int frame;
		protected char typePrefix;

		public PowerUp() : base ()
		{
			type = 1;
			frame = 0;
			setType();
		}

		public PowerUp(int x, int y, int wide, int high) : base (x, y, wide, high)
		{
			type = 1;
			frame = 0;
			setType();

		}

		public PowerUp(int x, int y, int wide, int high, Image i) : base (x, y, wide, high, i)
		{
			type = 1;
			frame = 0;
			setType();
		}


		public void Animate ()
		{
			setTop(getTop() + 3);
			String imageName = "images\\" + typePrefix + "-" + frame + ".png";
			setImage(Image.FromFile(imageName));
			if (frame < 7)
				frame++;
			else
				frame = 0;

	
		}

		public void Animate (int speed)
		{
			setTop(getTop() + speed);
			String imageName = "images\\" + typePrefix + "-" + frame + ".png";
			setImage(Image.FromFile(imageName));
			if (frame < 7)
				frame++;
			else
				frame = 0;
			
		}

		public void setType (int typeCode)
		{
			type = typeCode;
			setType();
		}

		public void setType ()
		{
			switch (type)
			{
				case 0:
					typePrefix = 'w';
					break;
				case 1:
					typePrefix = 's';
					type = 0; // remove this line!!!!!!!!!!!
					break;
				case 2:
					typePrefix = 'l';
					break;
				case 3:
					typePrefix = 'b';
					type = 0; // remove this line!!!!!!!
					break;
				case 4: 
					typePrefix = 'f';
					break;
				default:
					setType(type%4);
					break;
			}
		}

		public int getType ()
		{
			return type;
		}
	}
}
