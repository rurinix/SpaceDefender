using System;

namespace GameTools
{
	/// <summary>
	/// Summary description for CollisionDetection.
	/// </summary>
	public class CollisionDetection
	{
		public CollisionDetection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static bool LaserHitSquare(Laser laser, Ship ship)
		{
			bool returnVal = false;
			if (laser.isActive() && ship.isActive())
			{
				if (laser.getLeft() <= ship.getRight() && laser.getRight() >= ship.getLeft())
				{
					if (laser.getBottom() >= ship.getTop() && laser.getTop() <= ship.getBottom())
					{
						returnVal = true;
					}
				}
			}

			return returnVal;
		}

		public static bool LaserHitPyramid(Laser laser, Ship ship)
		{
			int distanceX;
			int distanceY = laser.getBottom() - ship.getTop();
			bool returnVal = false;
			if (laser.isActive() && ship.isActive())
			{
				if (laser.getLeft() <= ship.getRight() && laser.getRight() >= ship.getLeft())
				{
					if (laser.getBottom() >= ship.getTop() && laser.getTop() <= ship.getBottom())
					{
						if (laser.getLeft() > ship.getMiddleX())
							distanceX = laser.getLeft() - ship.getMiddleX();
					
						else if (laser.getRight() < ship.getMiddleX())
							distanceX = ship.getMiddleX() - laser.getRight();

						else
							distanceX = 0;

						if (distanceY > distanceX * 2)
						returnVal = true;
					}
				}
			}

			return returnVal;
		}

		public static bool LaserHitPentagon(Laser laser, Ship ship)
		{
			int distanceX;
			int distanceY = laser.getBottom() - ship.getTop();
			bool returnVal = false;
			if (laser.isActive() && ship.isActive())
			{
				if (laser.getLeft() <= ship.getRight() && laser.getRight() >= ship.getLeft())
				{
					if (laser.getBottom() >= ship.getTop() && laser.getTop() <= ship.getBottom())
					{
						if (laser.getLeft() > ship.getMiddleX())
							distanceX = laser.getLeft() - ship.getMiddleX();
					
						else if (laser.getRight() < ship.getMiddleX())
							distanceX = ship.getMiddleX() - laser.getRight();

						else
							distanceX = 0;

						if (distanceY > distanceX)
							returnVal = true;
					}
				}
			}

			return returnVal;
		}

		public static bool HitSquare(GameObject object1, GameObject object2)
		{
			bool returnVal = false;
			if (object1.isActive() && object2.isActive())
			{
				if (object1.getLeft() <= object2.getRight() && object1.getRight() >= object2.getLeft())
				{
					if (object1.getBottom() >= object2.getTop() && object1.getTop() <= object2.getBottom())
					{
						returnVal = true;
					}
				}
			}

			return returnVal;
		}
	}
}
