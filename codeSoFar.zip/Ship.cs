using System;
using System.Drawing;


namespace GameTools
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Ship : GameObject
	{
		
		public Laser[] laser = new Laser[25];
		protected int exhaustSize;

		protected int cooldownCounter;

		private System.Windows.Forms.Timer ExhaustTimer;

		public Ship() : base()
		{

			makeLasers();
			cooldownCounter = 15;
			active = true;
			ExhaustTimer = new System.Windows.Forms.Timer();
			ExhaustTimer.Enabled = true;
			ExhaustTimer.Interval = 60;
			ExhaustTimer.Tick += new System.EventHandler(this.ExhaustTimer_Tick);
			exhaustSize = 5;
		}

		public Ship (int x, int y, int wide, int high) : base (x, y, wide, high)
		{

			makeLasers();
			active = true;
			cooldownCounter = 15;
			ExhaustTimer = new System.Windows.Forms.Timer();
			ExhaustTimer.Enabled = true;
			ExhaustTimer.Interval = 60;
			ExhaustTimer.Tick += new System.EventHandler(this.ExhaustTimer_Tick);
			exhaustSize = 5;

		}

		public Ship (int x, int y, int wide, int high, Image i) : base (x, y, wide, high, i)
		{
			makeLasers();
			active = true;
			cooldownCounter = 15;
			ExhaustTimer = new System.Windows.Forms.Timer();
			ExhaustTimer.Enabled = true;
			ExhaustTimer.Interval = 60;
			ExhaustTimer.Tick += new System.EventHandler(this.ExhaustTimer_Tick);
			exhaustSize = 5;
		}

		public void tryToFire()
		{
			if (active)
			{
				for (int count = 0; count < this.laser.Length; count ++)
				{
					if (!this.laser[count].isActive())
					{
						this.laser[count].setActive(true);
						this.laser[count].setTop(this.getTop() + this.laser[count].getHeight());
						this.laser[count].setLeft(this.getMiddleX());
						count = this.laser.Length;
						Sound.FlushAudio();
						Sound.PlayAudioAsync("sounds\\laser.wav");
					}
				}
			}
		}

		protected void makeLasers()
		{
			for (int count = 0; count < laser.Length; count++)
				laser[count] = new Laser(this.getMiddleX(), this.getMiddleY(), 3, 9, 6, Color.White);

		}
		protected void makeLasers(int X, int Y, int wide, int tall, int speed, Color laserColor)
		{
			for (int count = 0; count < laser.Length; count++)
				laser[count] = new Laser(X, Y, wide, tall, speed, laserColor);

		}

		public void moveLasers(int X, int Y)
		{
				for (int count = 0; count < laser.Length; count++)
				{
					laser[count].setLeft(X);
					laser[count].setTop(Y);
					laser[count].setActive(false);
				}
		}

		public void AnimateLasersUp(int max)
		{
			for (int count = 0; count < laser.Length ; count++)
			{
					
				if (laser[count].isActive())
				{
					laser[count].setTop(laser[count].getTop() - laser[count].getSpeed());
					if (laser[count].getBottom() < max)
						laser[count].setActive(false);
				}
			}
		}

		public void AnimateLasersDown(int max)
		{
			for (int count = 0; count < laser.Length ; count++)
			{
					
				if (laser[count].isActive())
				{
					laser[count].setTop(laser[count].getTop() + laser[count].getSpeed());
					if (laser[count].getBottom() > max)
						laser[count].setActive(false);
				}
			}
		}

		public void drawLasers(Graphics g)
		{
			for (int count = 0; count < this.laser.Length; count++)
			{
				if (this.laser[count].isActive()) // only draw the lasers if they are active
					this.laser[count].Draw(g);						
			}
		}

		public void setLaserDelay (int laserDelay)
		{
			cooldownCounter = laserDelay;
		}

		public int getLaserDelay()
		{
			return cooldownCounter;
		}

		private void ExhaustTimer_Tick(object sender, System.EventArgs e)
		{
			if (exhaustSize < 10)
				exhaustSize++;
			else
				exhaustSize = 5;
		}

		public void Draw (Graphics g)
		{
			for (int count = this.getWidth()/4 + exhaustSize; count > 0; count--)
			{
				int trans = 255/count;
				g.DrawEllipse(new Pen(Color.FromArgb(trans, 240, 220, 85), 2), this.getMiddleX() - count/2, this.getBottom() - count/2, count, count);

			}
			for (int count = this.getWidth()/3 + exhaustSize; count > 0; count--)
			{
				int trans = 255/count;
				g.DrawEllipse(new Pen(Color.FromArgb(trans, 255, 150, 0), 2), this.getMiddleX() - count/2, this.getBottom()- count/2, count, count);

			}

			g.DrawImage(this.getImage(), this.getLeft(), this.getTop(), this.getWidth(), this.getHeight());

		}
	}
}
