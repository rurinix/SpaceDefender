using System;
using System.Drawing;

namespace GameTools
{
	/// <summary>
	/// Summary description for EnemyShip.
	/// </summary>
	public class EnemyShip : Ship
	{
		int points;
		int frame;

		bool goLeft;
		bool goRight;
		bool goUp;
		bool goDown;

		public EnemyShip() : base ()
		{
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Red);
			goLeft = false;
			goRight = false;
			goUp = false;
			goDown = false;
			frame = 0;
		}

		public EnemyShip (int x, int y, int wide, int high) : base (x, y, wide, high)
		{
			cooldownCounter = 6;
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Red);
			goLeft = false;
			goRight = false;
			goUp = false;
			goDown = false;
			image = null;
			frame = 0;

		}

		public EnemyShip (int x, int y, int wide, int high, Image i) : base (x, y, wide, high, i)
		{

			cooldownCounter = 6;
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Red);	
			goLeft = false;
			goRight = false;
			goUp = false;
			goDown = false;
			frame = 0;


		}
		public EnemyShip (int x, int y, int wide, int high, Image i, bool turnedOn) : base (x, y, wide, high, i)
		{
			active = turnedOn;
			cooldownCounter = 6;
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Red);
			goLeft = false;
			goRight = false;
			goUp = false;
			goDown = false;
			frame = 0;
		}

		public EnemyShip (int x, int y, int wide, int high, Image i, bool turnedOn, int pointValue) : base (x, y, wide, high, i)
		{

			active = turnedOn;
			points = pointValue;
			cooldownCounter = 6;
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Red);
			goLeft = false;
			goRight = false;
			goUp = false;
			goDown = false;
			image = i;
			frame = 0;

		}
		public EnemyShip (int x, int y, int wide, int high, Image i, bool turnedOn, int pointValue, int laserDelay) : base (x, y, wide, high, i)
		{
			active = turnedOn;
			points = pointValue;
			cooldownCounter = laserDelay;
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Red);
			goLeft = false;
			goRight = false;
			goUp = false;
			goDown = false;
			frame = 0;
		}

		public int getPointValue ()
		{
			return points;
		}

		public void directionChange(string direction)
		{
			direction.ToLower();
			switch (direction)
			{
				case "north":
				case "up":
					goDown = false;
					goUp = true;
					break;
				case "south":
				case "down":
					goDown = true;
					goUp = false;
					break;
				case "west":
				case "left":
					goLeft = true;
					goRight = false;
					break;
				case "east":
				case "right":
					goRight = true;
					goLeft = false;
					break;
				default:
					break;
			}
		}

		public void Animate ()
		{
			// move ship
			if (goUp)
				setTop(getTop() - 1);
			if (goDown)
				setTop(getTop() + 1);
			if (goLeft)
				setLeft(getLeft() - 1);
			if (goRight)
				setLeft(getLeft() + 1);
		}

		public void Animate (int shipType)
		{
			// move ship
			if (goUp)
				setTop(getTop() - 1);
			if (goDown)
				setTop(getTop() + 1);
			if (goLeft)
				setLeft(getLeft() - 1);
			if (goRight)
				setLeft(getLeft() + 1);

			//change image
			switch (shipType)
			{
				case 1:
					setImage(Image.FromFile("images\\saucer" + frame + ".png"));
					break;
				case 2:
					break;
				default:
					break;
			}

			if (frame < 5)
				frame++;
			else 
				frame = 0;
		}


	}
}
