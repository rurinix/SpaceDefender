using System;
using System.Drawing;


namespace GameTools
{
	/// <summary>
	/// Summary description for GameObjects.
	/// </summary>
	public abstract class GameObject
	{
		protected bool active;
		protected bool visible;

		protected int top;
		protected int bottom;
		protected int middleY;
		protected int middleX;
		protected int left;
		protected int right;
		protected int width;
		protected int height;

		protected Image image;


		public GameObject()
		{
			top = 0;
			bottom = 0;
			middleY = 0;
			middleX = 0;
			left = 0;
			right = 0;
		}

		public GameObject (int x, int y, int wide, int high)
		{
			top = y;
			left = x;
			width = wide;
			height = high;
			setBottom();
			setRight();
			setMiddleY();
			setMiddleX();

			image = null;

		}
		
		public GameObject (int x, int y, int wide, int high, Image i)
		{
			top = y;
			left = x;
			width = wide;
			height = high;
			setBottom();
			setRight();
			setMiddleY();
			setMiddleX();

			image = i;

		}

			
		public int getWidth()
		{
			return width;
		}

		public int getHeight()
		{
			return height;
		}

		public int getTop()
		{
			return top;
		}

		public int getBottom()
		{
			setBottom();
			return bottom;
		}
		
		public int getLeft ()
		{
			return left;
		}

		public int getRight ()
		{
			right = left + width;
			return right;
		}

		public int getMiddleY ()
		{
			setMiddleY();
			return middleY;
		}

		public int getMiddleX ()
		{
			setMiddleX();
			return middleX;
		}

		public Image getImage ()
		{
			return image;
		}

		public void setImage (Image i)
		{
			image = i;
		}

		public void setTop (int i)
		{
			top = i;
			setBottom();
			setMiddleY();
		}

		public void setLeft (int i)
		{
			left = i;
			setRight();
		}

		public void setBottom ()
		{
			bottom = top + height;
		}

		public void setRight ()
		{
			right = left + width;
		}

		public void setMiddleY ()
		{
			middleY = top + (height / 2);
		}

		public void setMiddleX ()
		{
			middleX = left + (width / 2);
		}

		public void setWidth(int i)
		{
			width = i;
		}

		public void setHeight (int i)
		{
			height = i;
		}

		public void setActive (bool trueFalse)
		{
			active = trueFalse;
		}

		public bool isActive ()
		{
			return active;
		}

		public void setVisible (bool trueFalse)
		{
			visible = trueFalse;
		}

		public bool isVisible ()
		{
			return visible;
		}
	}
}
