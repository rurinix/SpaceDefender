using System;
using System.Drawing;

namespace GameTools
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class HeroShip : Ship
	{
		public Ship[] wingman = new Ship[2];

		public HeroShip() : base ()
		{
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Blue);
			wingman[0] = new Ship(getLeft() - 25, getMiddleY() - 10, 25, 25, getImage());
			wingman[1] = new Ship(getRight(), getMiddleY() - 10, 25, 25, getImage());
			active = true;
		}

		public HeroShip (int x, int y, int wide, int high) : base (x, y, wide, high)
		{
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Blue);
			wingman[0] = new Ship(getLeft() - 25, getMiddleY() - 10, 25, 25, getImage());
			wingman[1] = new Ship(getRight(), getMiddleY() - 10, 25, 25, getImage());
			active = true;
		}

		public HeroShip (int x, int y, int wide, int high, Image i) : base (x, y, wide, high, i)
		{
			makeLasers(getMiddleX(), getMiddleY(), 3, 9, 6, Color.Blue);
			wingman[0] = new Ship(getLeft() - 25, getMiddleY() - 10, 25, 25, getImage());
			wingman[1] = new Ship(getRight(), getMiddleY() - 10, 25, 25, getImage());
			active = true;

			image = i;
		}
	}
}
