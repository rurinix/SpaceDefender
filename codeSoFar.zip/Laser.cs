using System;
using System.Drawing;

namespace GameTools
{
	/// <summary>
	/// Summary description for Laser.
	/// </summary>
	public class Laser : GameObject
	{
		int speed;
		Color c;

		public Laser()
		{
			active = false;
			setWidth(3);
			setHeight(10);
			speed = 6;
			c = Color.White;
		}

		public Laser(int X, int Y, Color color)
		{
			setTop(X);
			setLeft(Y);
			active = false;
			setWidth(3);
			setHeight(10);
			speed = 6;
			c = color;

		}
		public Laser (int X, int Y, int wide, int tall, int Speed, Color color)
		{
			setTop(X);
			setLeft(Y);
			setWidth(wide);
			setHeight(tall);
			speed = Speed;
			active = false;
			c = color;
		}

		public void setSpeed (int Speed)
		{
			speed = Speed;
		}

		public int getSpeed()
		{
			return speed;
		}

		public Color getColor ()
		{
			return c;
		}

		public void Draw (Graphics g)
		{
			if (c.Equals(Color.Blue))
			{
				g.DrawLine(new Pen(Color.FromArgb(155, 125, 125, 255), 2), this.getLeft() - 1, this.getTop() + 2, this.getLeft() - 1, this.getBottom() - 2);
				g.DrawLine(new Pen(Color.FromArgb(155, 220, 220, 135), 2), this.getLeft() + 1, this.getTop() + 2, this.getLeft() + 1, this.getBottom() - 2);
				g.DrawLine(new Pen(Color.FromArgb(255, 130, 130, 255), 2), this.getLeft(), this.getTop(), this.getLeft(), this.getBottom() );

			}
			else if (c.Equals(Color.Red))
			{
				g.DrawLine(new Pen(Color.FromArgb(155, 255, 180, 155), 2), this.getLeft() - 1, this.getTop() + 2, this.getLeft() - 1, this.getBottom() - 2);
				g.DrawLine(new Pen(Color.FromArgb(155, 225, 180, 180), 2), this.getLeft() + 1, this.getTop() + 2, this.getLeft() + 1, this.getBottom() - 2);
				g.DrawLine(new Pen(Color.FromArgb(255, 255, 125, 125), 2), this.getLeft(), this.getTop(), this.getLeft(), this.getBottom() );
			}
			else
			{
				g.DrawLine(new Pen(Color.FromArgb(155, 125, 125, 125), 2), this.getLeft() - 1, this.getTop() + 2, this.getLeft() - 1, this.getBottom() - 2);
				g.DrawLine(new Pen(Color.FromArgb(155, 180, 180, 180), 2), this.getLeft() + 1, this.getTop() + 2, this.getLeft() + 1, this.getBottom() - 2);
				g.DrawLine(new Pen(Color.FromArgb(255, 185, 185, 125), 2), this.getLeft(), this.getTop(), this.getLeft(), this.getBottom() );
			}	
		}
	}
}
